package com.wikibooks.chapter1.service;

public interface MyService {

    public String getHello();

}
