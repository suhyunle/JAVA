package design_pattern.adapter;

public interface Electronic110v {

    void power110vOn();

}
