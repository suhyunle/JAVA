package design_pattern.abstract_factory;

public class BObject implements AbstractObject{

    public void print() {
        System.out.println("B Object가 호출되었습니다.");
    }
}
