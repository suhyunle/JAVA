package com.springboot.hello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chapter4HelloApplicationTests {

    @Test
    void contextLoads() {
    }

}
